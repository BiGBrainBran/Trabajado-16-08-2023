package com.example.branbtns;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener{

    Button btnVolver;
    Button buttonCalculadora;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnVolver = (Button) findViewById(R.id.btnbac);
        buttonCalculadora = (Button) findViewById(R.id.btncalculator);

        btnVolver.setOnClickListener(this);
        buttonCalculadora.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnbac) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (view.getId() == R.id.btncalculator) {
            Intent intent = new Intent(this, MainActivity3.class);
            startActivity(intent);
        }
    }


}
