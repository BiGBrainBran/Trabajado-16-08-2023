package com.example.branbtns;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.branbtns.R;

public class MainActivity3 extends AppCompatActivity {

    private EditText pl1, pl2;
    private Button btnSuma, btnResta, btnMulti, btnDivi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        pl1 = findViewById(R.id.pl1);
        pl2 = findViewById(R.id.pl2);
        btnSuma = findViewById(R.id.btsuma);
        btnResta = findViewById(R.id.btresta);
        btnMulti = findViewById(R.id.btmulti);
        btnDivi = findViewById(R.id.btdivi);

        btnSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular('+');
            }
        });

        btnResta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular('-');
            }
        });

        btnMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular('*');
            }
        });

        btnDivi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular('/');
            }
        });
    }

    private void calcular(char operador) {
        String num1Str = pl1.getText().toString();
        String num2Str = pl2.getText().toString();



        if (!num1Str.isEmpty() && !num2Str.isEmpty()) {
            double num1 = Double.parseDouble(num1Str);
            double num2 = Double.parseDouble(num2Str);
            double resultado = 0;

            switch (operador) {
                case '+':
                    resultado = num1 + num2;
                    break;
                case '-':
                    resultado = num1 - num2;
                    break;
                case '*':
                    resultado = num1 * num2;
                    break;
                case '/':
                    if (num2 != 0) {
                        resultado = num1 / num2;
                    } else {

                    }
                    break;
            }

            TextView resultadotextview = findViewById(R.id.resultadotextview);
            resultadotextview.setText("Resultado: " + resultado);
        }
    }
}
